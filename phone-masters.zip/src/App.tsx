import React, { useState, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { ProductCard } from './components/ProductCard';
import { Cart } from './components/Cart';
import { CartProvider } from './context/CartContext';
import { products } from './data/products';
import { SlidersHorizontal, ChevronRight, CheckCircle2, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [selectedCondition, setSelectedCondition] = useState<string | null>(null);
  const [maxPrice, setMaxPrice] = useState<number>(2000);
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileFiltersOpen, setIsMobileFiltersOpen] = useState(false);
  const [sortBy, setSortBy] = useState('recommended');

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchBrand = selectedBrands.length === 0 || selectedBrands.includes(p.brand);
      const matchCondition = !selectedCondition || p.condition === selectedCondition;
      const matchPrice = p.price <= maxPrice;
      const matchSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.brand.toLowerCase().includes(searchQuery.toLowerCase());
      return matchBrand && matchCondition && matchPrice && matchSearch;
    }).sort((a, b) => {
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0; // recommended
    });
  }, [selectedBrands, selectedCondition, maxPrice, sortBy, searchQuery]);

  return (
    <CartProvider>
      <div className="min-h-screen bg-[#f4f4f7] font-sans text-slate-900 selection:bg-slate-200 selection:text-slate-900 flex flex-col">
        <Navbar searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
        <Cart />

        <main className="flex-1 container mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12 flex flex-col lg:flex-row gap-8 lg:gap-12">
          
          {/* Mobile Filters Toggle & Header Info */}
          <div className="lg:hidden w-full flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold">Catalog</h1>
              <p className="text-sm text-gray-500 mt-1">{filteredProducts.length} results found</p>
            </div>
            <button 
              onClick={() => setIsMobileFiltersOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg text-sm font-medium"
            >
              <SlidersHorizontal className="w-4 h-4" />
              Filters
            </button>
          </div>

          {/* Sidebar - Desktop */}
          <aside className="hidden lg:block shrink-0 w-64 pt-2">
            <Sidebar 
              selectedBrands={selectedBrands}
              setSelectedBrands={setSelectedBrands}
              selectedCondition={selectedCondition}
              setSelectedCondition={setSelectedCondition}
              maxPrice={maxPrice}
              setMaxPrice={setMaxPrice}
            />
          </aside>

          {/* Main Content Area */}
          <div className="flex-1">
            {/* Desktop Header & Sorting */}
            <div className="hidden lg:flex items-end justify-between mb-8 pb-6 border-b border-black/5">
              <div>
                <nav className="flex text-sm text-slate-400 mb-2 items-center gap-2">
                  <a href="#" className="hover:text-slate-900">Home</a>
                  <ChevronRight className="w-4 h-4" />
                  <a href="#" className="hover:text-slate-900">Phones</a>
                  <ChevronRight className="w-4 h-4" />
                  <span className="text-slate-900 font-medium">All Devices</span>
                </nav>
                <div className="flex items-baseline gap-4 mt-2">
                  <h1 className="text-4xl font-black tracking-tight text-slate-900">All Devices</h1>
                  <span className="text-slate-500 text-sm font-bold bg-white px-3 py-1 rounded-[8px] border border-black/5 shadow-sm">{filteredProducts.length} results</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-sm font-medium text-gray-500">Sort by:</span>
                <select 
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="bg-white border text-slate-600 border-black/5 rounded-xl text-sm font-semibold py-2.5 pl-4 pr-10 focus:ring-2 focus:ring-slate-900 cursor-pointer"
                >
                  <option value="recommended">Recommended</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="rating">Highest Rated</option>
                </select>
              </div>
            </div>

            {/* Product Grid */}
            {filteredProducts.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mb-6">
                  <Search className="w-10 h-10 text-gray-300" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">No matching phones found</h2>
                <p className="text-gray-500 max-w-md mx-auto mb-6">Try adjusting your filters or price range to find what you're looking for.</p>
                <button 
                  onClick={() => {
                    setSelectedBrands([]);
                    setSelectedCondition(null);
                    setMaxPrice(2000);
                  }}
                  className="px-6 py-2.5 bg-gray-900 text-white font-medium rounded-full hover:bg-gray-800 transition-colors"
                >
                  Clear all filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                <AnimatePresence>
                  {filteredProducts.map(product => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
        </main>

        <footer className="bg-gray-50 border-t border-gray-200 mt-auto py-12">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center text-sm text-gray-500">
            <p className="font-semibold text-gray-900 mb-2">Phone Masters © {new Date().getFullYear()}</p>
            <p className="max-w-xl mx-auto mb-4">
              Prototype e-commerce platform demonstrating modern UI/UX design, state management, and component architecture.
            </p>
            <div className="flex justify-center flex-wrap gap-4 mt-6 text-xs text-gray-400">
              <span className="flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5 text-green-500" /> Product Catalog</span>
              <span className="flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5 text-green-500" /> Advanced Filtering</span>
              <span className="flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5 text-green-500" /> State Management</span>
              <span className="flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5 text-green-500" /> Responsive Design</span>
            </div>
          </div>
        </footer>

        {/* Mobile Filters Modal */}
        <AnimatePresence>
          {isMobileFiltersOpen && (
            <motion.div
              initial={{ opacity: 0, y: '100%' }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-0 z-50 bg-white p-4 overflow-y-auto lg:hidden"
            >
              <div className="flex items-center justify-between mb-8 pb-4 border-b border-gray-100">
                <h2 className="text-xl font-bold">Filters</h2>
                <button 
                  onClick={() => setIsMobileFiltersOpen(false)}
                  className="px-4 py-2 bg-gray-100 text-sm font-medium rounded-full"
                >
                  Done
                </button>
              </div>
              <Sidebar 
                selectedBrands={selectedBrands}
                setSelectedBrands={setSelectedBrands}
                selectedCondition={selectedCondition}
                setSelectedCondition={setSelectedCondition}
                maxPrice={maxPrice}
                setMaxPrice={setMaxPrice}
                className="max-w-none pr-0"
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </CartProvider>
  );
}

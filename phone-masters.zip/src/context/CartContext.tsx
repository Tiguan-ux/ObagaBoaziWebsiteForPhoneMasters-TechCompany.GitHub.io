import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product } from '../data/products';

type CartItem = Product & { quantity: number; selectedStorage: string };

type CartContextType = {
  items: CartItem[];
  addToCart: (product: Product, storage: string) => void;
  removeFromCart: (id: string, storage: string) => void;
  updateQuantity: (id: string, storage: string, quantity: number) => void;
  clearCart: () => void;
  totalItems: number;
  totalPrice: number;
  isCartOpen: boolean;
  setIsCartOpen: (isOpen: boolean) => void;
};

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('phone-masters-cart');
    return saved ? JSON.parse(saved) : [];
  });
  const [isCartOpen, setIsCartOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('phone-masters-cart', JSON.stringify(items));
  }, [items]);

  const addToCart = (product: Product, storage: string) => {
    setItems(prev => {
      const existing = prev.find(item => item.id === product.id && item.selectedStorage === storage);
      if (existing) {
        return prev.map(item => 
          item.id === product.id && item.selectedStorage === storage
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...product, quantity: 1, selectedStorage: storage }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (id: string, storage: string) => {
    setItems(prev => prev.filter(item => !(item.id === id && item.selectedStorage === storage)));
  };

  const updateQuantity = (id: string, storage: string, quantity: number) => {
    if (quantity < 1) {
      removeFromCart(id, storage);
      return;
    }
    setItems(prev => prev.map(item => 
      item.id === id && item.selectedStorage === storage
        ? { ...item, quantity }
        : item
    ));
  };

  const clearCart = () => setItems([]);

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  return (
    <CartContext.Provider value={{
      items, addToCart, removeFromCart, updateQuantity, clearCart,
      totalItems, totalPrice, isCartOpen, setIsCartOpen
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}

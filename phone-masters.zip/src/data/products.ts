export type Product = {
  id: string;
  name: string;
  brand: string;
  price: number;
  originalPrice?: number;
  storage: string[];
  condition: "New" | "Refurbished";
  image: string;
  rating: number;
  reviews: number;
  specs: {
    screen: string;
    camera: string;
    battery: string;
  };
};

export const products: Product[] = [
  {
    id: "p1",
    name: "iPhone 15 Pro Max",
    brand: "Apple",
    price: 1199,
    storage: ["256GB", "512GB", "1TB"],
    condition: "New",
    image: "https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&q=80&w=800",
    rating: 4.9,
    reviews: 1240,
    specs: {
      screen: "6.7\" Super Retina XDR",
      camera: "48MP Main | 12MP Ultra Wide | 12MP Telephoto",
      battery: "4422 mAh"
    }
  },
  {
    id: "p2",
    name: "Samsung Galaxy S24 Ultra",
    brand: "Samsung",
    price: 1299,
    storage: ["256GB", "512GB", "1TB"],
    condition: "New",
    image: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?auto=format&fit=crop&q=80&w=800",
    rating: 4.8,
    reviews: 856,
    specs: {
      screen: "6.8\" Dynamic AMOLED 2X",
      camera: "200MP Main | 50MP Periscope | 12MP Ultra Wide",
      battery: "5000 mAh"
    }
  },
  {
    id: "p3",
    name: "Google Pixel 8 Pro",
    brand: "Google",
    price: 899,
    originalPrice: 999,
    storage: ["128GB", "256GB", "512GB"],
    condition: "New",
    image: "https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&q=80&w=800",
    rating: 4.7,
    reviews: 642,
    specs: {
      screen: "6.7\" Super Actua",
      camera: "50MP Main | 48MP Ultra Wide | 48MP Telephoto",
      battery: "5050 mAh"
    }
  },
  {
    id: "p4",
    name: "iPhone 13 Pro",
    brand: "Apple",
    price: 549,
    originalPrice: 699,
    storage: ["128GB", "256GB"],
    condition: "Refurbished",
    image: "https://images.unsplash.com/photo-1632661674596-df8be070a5c5?auto=format&fit=crop&q=80&w=800",
    rating: 4.6,
    reviews: 2104,
    specs: {
      screen: "6.1\" Super Retina XDR",
      camera: "12MP Pro camera system",
      battery: "3095 mAh"
    }
  },
  {
    id: "p5",
    name: "Samsung Galaxy Z Fold 5",
    brand: "Samsung",
    price: 1499,
    originalPrice: 1799,
    storage: ["256GB", "512GB"],
    condition: "New",
    image: "https://images.unsplash.com/photo-1627389955805-4f40445d4722?auto=format&fit=crop&q=80&w=800",
    rating: 4.5,
    reviews: 320,
    specs: {
      screen: "7.6\" Dynamic AMOLED 2X (Main)",
      camera: "50MP Main | 12MP Ultra Wide | 10MP Telephoto",
      battery: "4400 mAh"
    }
  },
  {
    id: "p6",
    name: "OnePlus 12",
    brand: "OnePlus",
    price: 799,
    storage: ["256GB", "512GB"],
    condition: "New",
    image: "https://images.unsplash.com/photo-1678911820864-e2c567c655d7?auto=format&fit=crop&q=80&w=800",
    rating: 4.7,
    reviews: 412,
    specs: {
      screen: "6.82\" ProXDR display",
      camera: "50MP Main | 64MP Periscope | 48MP Ultra Wide",
      battery: "5400 mAh"
    }
  },
  {
    id: "p7",
    name: "iPhone 11",
    brand: "Apple",
    price: 249,
    originalPrice: 299,
    storage: ["64GB", "128GB"],
    condition: "Refurbished",
    image: "https://images.unsplash.com/photo-1574755393849-623942496936?auto=format&fit=crop&q=80&w=800",
    rating: 4.4,
    reviews: 5890,
    specs: {
      screen: "6.1\" Liquid Retina HD",
      camera: "12MP Dual camera system",
      battery: "3110 mAh"
    }
  },
  {
    id: "p8",
    name: "Google Pixel 7a",
    brand: "Google",
    price: 399,
    originalPrice: 499,
    storage: ["128GB"],
    condition: "New",
    image: "https://images.unsplash.com/photo-1612442449559-99f57eb9287c?auto=format&fit=crop&q=80&w=800",
    rating: 4.6,
    reviews: 954,
    specs: {
      screen: "6.1\" OLED display",
      camera: "64MP Main | 13MP Ultra Wide",
      battery: "4385 mAh"
    }
  }
];
